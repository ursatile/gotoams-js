export default class CountingEngine {    
    constructor(count) {
        console.warn('CountingEngine.constructor() is not implemented!');
    }
    increment() {
        throw('CountingEngine.increment() is not implemented!');
    }
    decrement() {
        throw('CountingEngine.decrement() is not implemented!');
    }    
    reset() {
        throw('CountingEngine.reset() is not implemented!');
    }
}